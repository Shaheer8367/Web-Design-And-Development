-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2024 at 01:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task1`
--

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `Full_Name` varchar(30) NOT NULL,
  `DateOfBirth` varchar(30) NOT NULL DEFAULT '',
  `Email` varchar(30) NOT NULL,
  `MobNumber` int(20) NOT NULL,
  `Gender` text NOT NULL,
  `Occupation` text NOT NULL,
  `IDtype` text NOT NULL,
  `IDnumber` int(15) NOT NULL,
  `IssueAuthority` varchar(20) NOT NULL,
  `IssueDate` date NOT NULL,
  `IssueState` text NOT NULL,
  `ExpiryDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`Full_Name`, `DateOfBirth`, `Email`, `MobNumber`, `Gender`, `Occupation`, `IDtype`, `IDnumber`, `IssueAuthority`, `IssueDate`, `IssueState`, `ExpiryDate`) VALUES
('MUHAMMAD MUSTAFA', '2024-07-08', 'mustafashafi143@gmail.com', 2147483647, 'male', 'student', 'CNIC', 207734, 'Pakistan', '2024-07-01', 'pakistan', '2024-07-17'),
('MUHAMMAD MUSTAFA', '2024-07-24', 'mustafa@yahoo.com', 2147483647, 'male', 'student', 'CNIC', 2079767, 'Pakistan', '2024-07-07', 'pakistan', '2024-07-31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`IDnumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
