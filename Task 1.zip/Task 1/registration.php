<?php
require_once("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <form id="registrationForm" action="submit.php" method="POST">
            <h1 style="margin: 15px; margin-bottom :50px;">Registration</h1>
            <div class="section">
                <h3 style="margin: 15px; margin-bottom :50px;">Personal Details</h3>

    <div class="row">

                    <div class="col-1">
                <label for="fullName" style="margin-bottom: 30px;">Full Name</label>
                <input type="text" placeholder="Enter your name" id="fullName" name="fullName" required style="padding: 20px;">
                     </div>  
                
            <div class="col-2">
                <label for="dob" style="margin-bottom: 30px;">Date of Birth</label>
                <input type="date" id="dob" name="dob" required style="padding: 20px;">
            </div>
            <div class="col-3">
                <label for="email" style="margin-bottom: 30px;">Email</label>
                <input type="email" placeholder="Enter your email" id="email" name="email" required style="padding: 20px;">
            </div>

     </div>
        
     
    <div class="row">
        <div class="col-1">
            <label for="fullName" style="margin-bottom: 30px;">Mobile number</label>
            <input type="text" placeholder="Enter mobile number" id="fullName" name="mobile" required style="padding: 20px;">
                 </div>  
            
        <div class="col-2">
            <label for="dob" style="margin-bottom: 30px;">Gender</label>
            <input type="text" placeholder="Enter your gender" id="dob" name="gender" required style="padding: 20px;">
        </div>
        <div class="col-3">
            <label for="email" style="margin-bottom: 30px;">Occupation</label>
            <input type="text" placeholder="Enter occupation" id="email" name="occupation" required style="padding: 20px;">
        </div>

    </div>


    <h3 style="margin: 15px; margin-bottom :30px;">Identity Details</h3>


    <div class="row">
        <div class="col-1">
            <label for="fullName" style="margin-bottom: 30px;">ID Type</label>
            <input type="text" placeholder="Enter ID type" id="fullName" name="idType" required style="padding: 20px;">
                 </div>  
            
        <div class="col-2">
            <label for="dob" style="margin-bottom: 30px;">ID Number</label>
            <input type="text" placeholder="Enter ID number" id="dob" name="idNumber" required style="padding: 20px;">
        </div>
        <div class="col-3">
            <label for="email" style="margin-bottom: 30px;">Issue Authority</label>
            <input type="text" placeholder="Enter issue department" id="email" name="issueAuthority" required style="padding: 20px;">
        </div>

    </div>


    <div class="row">
        <div class="col-1">
            <label for="fullName" style="margin-bottom: 30px;">Issue Date</label>
            <input type="date" id="fullName" name="issueDate" required style="padding: 20px;">
                 </div>  
            
        <div class="col-2">
            <label for="dob" style="margin-bottom: 30px;">Issue State</label>
            <input type="text" placeholder="Enter ID issue state" id="dob" name="issueState" required style="padding: 20px;">
        </div>
        <div class="col-3">
            <label for="email" style="margin-bottom: 30px;">Expiry Date</label>
            <input type="text" placeholder="Enter ID expire date" id="email" name="expiryDate" required style="padding: 20px;">
        </div>

    </div>

           
            <button type="submit" name="Next">Next -></button>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>

</body>
</html>