document.getElementById('registrationForm').addEventListener('submit', function(event) {
    let isValid = true;

    const fields = ['fullName', 'dob', 'email', 'mobile', 'gender', 'occupation', 'idType', 'idNumber', 'issueAuthority', 'issueDate', 'issueState', 'expiryDate'];
    
    fields.forEach(field => {
        const input = document.getElementById(field);
        if (!input.value) {
            isValid = false;
            input.style.borderColor = 'red';
        } else {
            input.style.borderColor = '';
        }
    });

    if (!isValid) {
        event.preventDefault();
        alert('Please fill all the fields');
    }
});
