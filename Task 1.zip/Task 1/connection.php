<?php 
session_start();

$con = mysqli_connect("localhost","root","","task1");
if(mysqli_connect_error()){
    echo "connection failed";
}


?>