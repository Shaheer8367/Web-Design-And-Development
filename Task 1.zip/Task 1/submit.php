<?php
require_once('connection.php');

if(isset($_POST['Next'])){
    $fullName = $_POST['fullName'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];
    $occupation = $_POST['occupation'];
    $idType = $_POST['idType'];
    $idNumber = $_POST['idNumber'];
    $issueAuthority = $_POST['issueAuthority'];
    $issueDate = $_POST['issueDate'];
    $issueState = $_POST['issueState'];
    $expiryDate = $_POST['expiryDate'];
    

    $query = "INSERT INTO `form` VALUES('$fullName','$dob','$email','$mobile', '$gender','$occupation','$idType'
    ,'$idNumber','$issueAuthority','$issueDate', '$issueState','$expiryDate') ";

    if(mysqli_query($con,$query)){
        $_SESSION['message'] = '<div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <i class="icon fas fa-check"></i> 
            Book Record Uploaded Successfully!
        </div>';
        
    }else{
        $_SESSION['message'] = '<div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <i class="icon fas fa-ban"></i> 
            Book Record Uploading Failed!
        </div>';
    }
    header('location:display.php');

}


?>